import e from "express";
import { Student } from "../models/student.model.js";

// scholarshipController.js



// POST /api/scholarships/match
export const matchScholarships = async (req, res) => {
  try {
    const { course, gpa, location, income, categories = [], interests } = req.body;

    const query = {
      // Course match (exact or open)
      $or: [
        { eligible_courses: { $in: [course] } },
        { eligible_courses: { $in: ['All', 'Any'] } }
      ],

      // GPA requirement
      min_gpa: { $lte: parseFloat(gpa) || 0 },

      // Income criteria (if any set)
      $or: [
        { income_criteria: { $exists: false } },
        { income_criteria: { $gte: parseInt(income) || 0 } }
      ],

      // Location match (loose)
      locations: { $in: [location, 'All', 'Any'] },

      // Categories (at least one match if required)
      ...(categories.length > 0 && {
        categories: { $in: categories }
      }),
    };

    const scholarships = await Student.find(query).lean();

    // Optional: Further refine by checking `interests` keyword matching with `title` or `description`
    const matched = interests
      ? scholarships.filter((sch) => {
          const keyword = interests.toLowerCase();
          return (
            sch.title?.toLowerCase().includes(keyword) ||
            sch.description?.toLowerCase().includes(keyword)
          );
        })
      : scholarships;

    res.status(200).json({ matched });
  } catch (error) {
    console.error('Match error:', error.message);
    res.status(500).json({ message: 'Server Error. Please try again later.' });
  }
};
