import mongoose, { Schema } from "mongoose";


const studentSchema = new Schema({
   title: String,
  eligible_courses: [String],  // e.g., ["BTech", "MTech"]
  min_gpa: Number,
  income_criteria: Number,
  locations: [String],         // e.g., ["Delhi", "Mumbai", "All"]
  categories: [String],        // e.g., ["SC", "ST", "OBC"]
  description: String,
  amount: String,
  deadline: String,
  link: String
  
  
});


export const Student = mongoose.model("Studentschema", studentSchema);